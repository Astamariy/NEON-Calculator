//
//  WatchConnectSpace.swift
//  NEON Calculator
//
//  Created by Александр Рузманов on 27.01.17.
//  Copyright © 2017 Александр Рузманов. All rights reserved.
//

import Foundation
import WatchConnectivity

class WatchConnectSpace: WCSession {
    
    private var session: WCSession?
    
    
    // take Apple watch's display text
    
    func takeInfo() -> String {
        if WCSession.isSupported() {
            session = WCSession.default()
            session?.delegate = delegate.self
            session?.activate()
            return downloadInfo()
        } else {
            return "ERROR"
        }
    }
    
    private func downloadInfo() -> String {
        if let watchDataBase = session?.applicationContext as? [String:String] {
            if let watchDisplayValue = watchDataBase["Watch Display Value"] {
                return watchDisplayValue
            } else {
                return "ERROR"
            }
        } else {
            return "ERROR"
        }
    }
    
    
    // send display text to Apple Watch
    
    func shareInfo(displayValue: String) {
        if WCSession.isSupported() {
            session = WCSession.default()
            session?.delegate = delegate.self
            session?.activate()
            if let validSession = session {
                let phoneDataBase = ["Phone Display Walue" : displayValue]
                do {
                    try validSession.updateApplicationContext(phoneDataBase)
                } catch {
                    print("ERROR in share phone info process")
                }
            }
        } else {
            print("ERROR in session activate process")
        }
    }
    
    init(displayValue: String) {
        
    }
 
}
