//
//  MainViewController.swift
//  Calculator PRO
//
//  Created by Александр Рузманов on 12.01.17.
//  Copyright © 2017 Александр Рузманов. All rights reserved.
//

import UIKit
import WatchConnectivity



class MainViewController: UIViewController {
    
    private func animateButton(button: UIButton, duration: Double, delay: Double) {
        button.backgroundColor = UIColor.black
        UIView.animate(withDuration: duration, delay: delay, animations: {
            button.backgroundColor = UIColor.white
        }) { (finished) in
            if finished {
                UIView.animate(withDuration: duration, delay: delay, animations: {
                    button.backgroundColor = UIColor.black
                }) { (finished) in
                    if finished {
                    }
            }
            }}}
    private var DegRad = UserDefaults.standard.bool(forKey: "Deg/Rad settings")
    private var userIsTheMiddleOfTyping = false
    private var itIsFirstPushOnPointButton = true
    private var colorHasChanged = UserDefaults.standard.bool(forKey: "savedSettings")
    
    @IBOutlet private weak var DegRadButton: UIButton!
    
    @IBAction func ChangeDegRad(_ sender: UIButton) {
        if DegRad {
            UserDefaults.standard.set(false, forKey: "Deg/Rad settings")
            DegRad = UserDefaults.standard.bool(forKey: "Deg/Rad settings")
            sender.setTitle("RAD", for: UIControlState.normal)
        } else {
            UserDefaults.standard.set(true, forKey: "Deg/Rad settings")
            DegRad = UserDefaults.standard.bool(forKey: "Deg/Rad settings")
            sender.setTitle("DEG", for: UIControlState.normal)
        }
        
        
    }
    
    
   @IBOutlet private  var DeleteSwipe: UISwipeGestureRecognizer!
    
   @IBAction private  func Delete(_ sender: UISwipeGestureRecognizer) {
    if Display.text!.characters.count == 1 {
        Display.text = "0"
        userIsTheMiddleOfTyping = false
    }
    else {
        var displayValue = Display.text!
        if displayValue.characters.last == "."{
            itIsFirstPushOnPointButton = true
        }
        displayValue = displayValue.substring(to: displayValue.index(before: displayValue.endIndex))
        Display.text = displayValue
        }
    }
    

   @IBAction private func ChangeColorTheme(_ sender: UIButton) {
        if colorHasChanged {
           UserDefaults.standard.set(false, forKey: "savedSettings")
            userIsTheMiddleOfTyping = UserDefaults.standard.bool(forKey: "savedSettings")
            colorHasChanged = UserDefaults.standard.bool(forKey: "savedSettings")
            viewDidLoad()
            
        } else {
           UserDefaults.standard.set(true, forKey: "savedSettings")
            userIsTheMiddleOfTyping = UserDefaults.standard.bool(forKey: "savedSettings")
            colorHasChanged = UserDefaults.standard.bool(forKey: "savedSettings")
            viewDidLoad()
           
        }
    }
    

    
  private  func setColorScheme(color: UIColor) {
        x2.setTitleColor(color, for: UIControlState.normal)
        xy.setTitleColor(color, for: UIControlState.normal)
        factorialX.setTitleColor(color, for: UIControlState.normal)
        lg.setTitleColor(color, for: UIControlState.normal)
        ln.setTitleColor(color, for: UIControlState.normal)
        e.setTitleColor(color, for: UIControlState.normal)
        ex.setTitleColor(color, for: UIControlState.normal)
        PI.setTitleColor(color, for: UIControlState.normal)
        root.setTitleColor(color, for: UIControlState.normal)
        sqrt.setTitleColor(color, for: UIControlState.normal)
        x.setTitleColor(color, for: UIControlState.normal)
        plusMinus.setTitleColor(color, for: UIControlState.normal)
        cos.setTitleColor(color, for: UIControlState.normal)
        divide.setTitleColor(color, for: UIControlState.normal)
        sin.setTitleColor(color, for: UIControlState.normal)
        multiply.setTitleColor(color, for: UIControlState.normal)
        tg.setTitleColor(color, for: UIControlState.normal)
        minus.setTitleColor(color, for: UIControlState.normal)
        setMemory.setTitleColor(color, for: UIControlState.normal)
        dot.setTitleColor(color, for: UIControlState.normal)
        equal.setTitleColor(color, for: UIControlState.normal)
        plus.setTitleColor(color, for: UIControlState.normal)
        memory.setTitleColor(color, for: UIControlState.normal)
    }
    
    private func setColorSchemeForNumbers(color: UIColor) {
        number0.setTitleColor(color, for: UIControlState.normal)
        number1.setTitleColor(color, for: UIControlState.normal)
        number2.setTitleColor(color, for: UIControlState.normal)
        number3.setTitleColor(color, for: UIControlState.normal)
        number4.setTitleColor(color, for: UIControlState.normal)
        number5.setTitleColor(color, for: UIControlState.normal)
        number6.setTitleColor(color, for: UIControlState.normal)
        number7.setTitleColor(color, for: UIControlState.normal)
        number8.setTitleColor(color, for: UIControlState.normal)
        number9.setTitleColor(color, for: UIControlState.normal)
    }
    
   
    @IBOutlet private weak var x2: UIButton!
    @IBOutlet private weak var xy: UIButton!
    @IBOutlet private weak var factorialX: UIButton!
    @IBOutlet private weak var lg: UIButton!
    @IBOutlet private weak var ln: UIButton!
    @IBOutlet private weak var e: UIButton!
    @IBOutlet private weak var ex: UIButton!
    @IBOutlet private weak var PI: UIButton!
    @IBOutlet private weak var root: UIButton!
    @IBOutlet private weak var sqrt: UIButton!
    @IBOutlet private weak var x: UIButton!
    @IBOutlet private weak var plusMinus: UIButton!
    @IBOutlet private weak var cos: UIButton!
    @IBOutlet private weak var divide: UIButton!
    @IBOutlet private weak var sin: UIButton!
    @IBOutlet private weak var multiply: UIButton!
    @IBOutlet private weak var tg: UIButton!
    @IBOutlet private weak var minus: UIButton!
    @IBOutlet private weak var setMemory: UIButton!
    @IBOutlet private weak var dot: UIButton!
    @IBOutlet private weak var equal: UIButton!
    @IBOutlet private weak var plus: UIButton!
    @IBOutlet private weak var memory: UIButton!
    @IBOutlet private weak var c: UIButton!
    @IBOutlet private weak var ce: UIButton!
    @IBOutlet private weak var number1: UIButton!
    @IBOutlet private weak var number2: UIButton!
    @IBOutlet private weak var number3: UIButton!
    @IBOutlet private weak var number4: UIButton!
    @IBOutlet private weak var number5: UIButton!
    @IBOutlet private weak var number6: UIButton!
    @IBOutlet private weak var number7: UIButton!
    @IBOutlet private weak var number8: UIButton!
    @IBOutlet private weak var number9: UIButton!
    @IBOutlet private weak var number0: UIButton!
    @IBOutlet private weak var changeThemeButton: UIButton!
    
    
    
  
   
    
    @IBOutlet private weak var Display: UILabel!     
    @IBAction private func PressNumber(_ sender: UIButton) {
        DeleteSwipe.isEnabled = true
         animateButton(button: sender, duration: 0.05, delay: 0)
    
    if userIsTheMiddleOfTyping
    {
        if Display.text != "0" {
            Display.text = Display.text! + sender.currentTitle!
            
        }
        else {
             Display.text = sender.currentTitle!
            
        }
        
    }
    else {
       
            Display.text = sender.currentTitle!
            userIsTheMiddleOfTyping = true
        
   
                }
        
    }
    
    @IBAction private func PressReset(_ sender: UIButton) {
        DeleteSwipe.isEnabled = false
        animateButton(button: sender, duration: 0.05, delay: 0)
        Display.text = "0"
        userIsTheMiddleOfTyping = false
        itIsFirstPushOnPointButton = true
        
        if sender.currentTitle == "C"
        {
        performOperation.resetAll()
        }
    }
    
    @IBAction func PressPoint(_ sender: UIButton) {
         animateButton(button: sender, duration: 0.05, delay: 0)
        if itIsFirstPushOnPointButton {
            if userIsTheMiddleOfTyping {
            Display.text = Display.text! + "."
            itIsFirstPushOnPointButton = false
                
            } else {
                if Display.text == "0" {
                    DeleteSwipe.isEnabled = true
                    Display.text = Display.text! + "."
                    itIsFirstPushOnPointButton = false
                    userIsTheMiddleOfTyping = true
                    
                }
            }
        } else {
            
        }
        
    }
    
    private var performOperation: Processor = Processor()
  
    @IBAction private func PressOperation(_ sender: UIButton) {
        DeleteSwipe.isEnabled = false
         animateButton(button: sender, duration: 0.05, delay: 0)
        
        if var value = Double(Display.text!)
        
     {
        if DegRadButton.currentTitle! == "DEG" && (sender.currentTitle! == "sin" || sender.currentTitle! == "cos" || sender.currentTitle! == "tg") {
            value = value * M_PI / 180
        }
        performOperation.setAccumulator(operand: value)
        Display.text = performOperation.returnAnswer(operationSymbol: sender.currentTitle!)
        
        } else {
        Display.text = "ERROR"
        }
        userIsTheMiddleOfTyping = false
        itIsFirstPushOnPointButton = true
        }
    
    
    
    @IBAction  private func saveToMemory(_ sender: UIButton) {
         animateButton(button: sender, duration: 0.05, delay: 0)
        if Display.text != "0"{
        if let val = Double(Display.text!)
        {
            performOperation.saveData(value: val)
        }
        
        } else {
            performOperation.resetData()
        }
    }
    
    @IBAction private func ShowMemory(_ sender: UIButton) {
        DeleteSwipe.isEnabled = false
         animateButton(button: sender, duration: 0.05, delay: 0)
        if performOperation.memory != nil
        {
        Display.text =  "\(performOperation.memory!)"
           
        }
    }
    
   override func viewDidLoad() {
    super.viewDidLoad()
        
        if colorHasChanged {
            
            if DegRad {
                DegRadButton.setTitle("DEG", for: UIControlState.normal)
            } else {
               DegRadButton.setTitle("RAD", for: UIControlState.normal)
            }
                changeThemeButton.setTitleColor(UIColor.white, for: UIControlState.normal)
            changeThemeButton.setTitle("White", for: UIControlState.normal)
            x2.setImage(UIImage(named: "x2.png"), for: UIControlState.normal)
            xy.setImage(UIImage(named: "xy.png"), for: UIControlState.normal)
            factorialX.setImage(UIImage(named: "factorialx.png"), for: UIControlState.normal)
            lg.setImage(UIImage(named: "lg.png"), for: UIControlState.normal)
            ln.setImage(UIImage(named: "ln.png"), for: UIControlState.normal)
            e.setImage(UIImage(named: "e.png"), for: UIControlState.normal)
            ex.setImage(UIImage(named: "ex.png"), for: UIControlState.normal)
            PI.setImage(UIImage(named: "pi.png"), for: UIControlState.normal)
            sqrt.setImage(UIImage(named: "sqrt.png"), for: UIControlState.normal)
            root.setImage(UIImage(named: "sqrt3.png"), for: UIControlState.normal)
            x.setImage(UIImage(named: "onedividex.png"), for: UIControlState.normal)
            plusMinus.setImage(UIImage(named: "plusminus.png"), for: UIControlState.normal)
            cos.setImage(UIImage(named: "cos.png"), for: UIControlState.normal)
            sin.setImage(UIImage(named: "sin.png"), for: UIControlState.normal)
            divide.setImage(UIImage(named: "divide.png"), for: UIControlState.normal)
            number3.setImage(UIImage(named: "three.png"), for: UIControlState.normal)
            number2.setImage(UIImage(named: "two.png"), for: UIControlState.normal)
            number1.setImage(UIImage(named: "one.png"), for: UIControlState.normal)
            number4.setImage(UIImage(named: "four.png"), for: UIControlState.normal)
            number5.setImage(UIImage(named: "five.png"), for: UIControlState.normal)
            number6.setImage(UIImage(named: "six.png"), for: UIControlState.normal)
            multiply.setImage(UIImage(named: "multiply.png"), for: UIControlState.normal)
            tg.setImage(UIImage(named: "tg.png"), for: UIControlState.normal)
            number7.setImage(UIImage(named: "seven.png"), for: UIControlState.normal)
            number8.setImage(UIImage(named: "eight.png"), for: UIControlState.normal)
            number9.setImage(UIImage(named: "nine.png"), for: UIControlState.normal)
            minus.setImage(UIImage(named: "minus.png"), for: UIControlState.normal)
            setMemory.setImage(UIImage(named: "xm.png"), for: UIControlState.normal)
            dot.setImage(UIImage(named: "dot.png"), for: UIControlState.normal)
            number0.setImage(UIImage(named: "zero.png"), for: UIControlState.normal)
            equal.setImage(UIImage(named: "equal.png"), for: UIControlState.normal)
            plus.setImage(UIImage(named: "plus.png"), for: UIControlState.normal)
            memory.setImage(UIImage(named: "m.png"), for: UIControlState.normal)
            c.setImage(UIImage(named: "c.png"), for: UIControlState.normal)
            ce.setImage(UIImage(named: "ce.png"), for: UIControlState.normal)
            Display.textColor = UIColor(red: 0, green: 1, blue: 1, alpha: 1)
            setColorScheme(color: UIColor(red: 0.391, green: 0.668, blue: 1, alpha: 1))
            setColorSchemeForNumbers(color: UIColor(red: 1, green: 0.328, blue: 0.401, alpha: 1))
            c.setTitleColor(UIColor(red: 0, green: 1, blue: 1, alpha: 1), for: UIControlState.normal)
            ce.setTitleColor(UIColor(red: 1, green: 0, blue: 1, alpha: 1), for: UIControlState.normal)
            DegRadButton.setTitleColor(UIColor.white, for: UIControlState.normal)
        } else {
            if DegRad {
                DegRadButton.setTitle("DEG", for: UIControlState.normal)
            } else {
                DegRadButton.setTitle("RAD", for: UIControlState.normal)
            }
            changeThemeButton.setTitleColor(UIColor(red: 0, green: 1, blue: 1, alpha: 1), for: UIControlState.normal)
            changeThemeButton.setTitle("NEON", for: UIControlState.normal)
            x2.setImage(UIImage(named: "x2white.png"), for: UIControlState.normal)
            xy.setImage(UIImage(named: "xywhite.png"), for: UIControlState.normal)
            factorialX.setImage(UIImage(named: "factorialxwhite.png"), for: UIControlState.normal)
            lg.setImage(UIImage(named: "lgwhite.png"), for: UIControlState.normal)
            ln.setImage(UIImage(named: "lnwhite.png"), for: UIControlState.normal)
            e.setImage(UIImage(named: "ewhite.png"), for: UIControlState.normal)
            ex.setImage(UIImage(named: "exwhite.png"), for: UIControlState.normal)
            PI.setImage(UIImage(named: "piwhite.png"), for: UIControlState.normal)
            sqrt.setImage(UIImage(named: "sqrtwhite.png"), for: UIControlState.normal)
            root.setImage(UIImage(named: "sqrt3white.png"), for: UIControlState.normal)
            x.setImage(UIImage(named: "onedividexwhite.png"), for: UIControlState.normal)
            plusMinus.setImage(UIImage(named: "plusminuswhite.png"), for: UIControlState.normal)
            cos.setImage(UIImage(named: "coswhite.png"), for: UIControlState.normal)
            sin.setImage(UIImage(named: "sinwhite.png"), for: UIControlState.normal)
            divide.setImage(UIImage(named: "dividewhite.png"), for: UIControlState.normal)
            number3.setImage(UIImage(named: "threewhite.png"), for: UIControlState.normal)
            number2.setImage(UIImage(named: "twowhite.png"), for: UIControlState.normal)
            number1.setImage(UIImage(named: "onewhite.png"), for: UIControlState.normal)
            number4.setImage(UIImage(named: "fourwhite.png"), for: UIControlState.normal)
            number5.setImage(UIImage(named: "fivewhite.png"), for: UIControlState.normal)
            number6.setImage(UIImage(named: "sixwhite.png"), for: UIControlState.normal)
            multiply.setImage(UIImage(named: "multiplywhite.png"), for: UIControlState.normal)
            tg.setImage(UIImage(named: "tgwhite.png"), for: UIControlState.normal)
            number7.setImage(UIImage(named: "sevenwhite.png"), for: UIControlState.normal)
            number8.setImage(UIImage(named: "eightwhite.png"), for: UIControlState.normal)
            number9.setImage(UIImage(named: "ninewhite.png"), for: UIControlState.normal)
            minus.setImage(UIImage(named: "minuswhite.png"), for: UIControlState.normal)
            setMemory.setImage(UIImage(named: "xmwhite.png"), for: UIControlState.normal)
            dot.setImage(UIImage(named: "dotwhite.png"), for: UIControlState.normal)
            number0.setImage(UIImage(named: "zerowhite.png"), for: UIControlState.normal)
            equal.setImage(UIImage(named: "equalwhite.png"), for: UIControlState.normal)
            plus.setImage(UIImage(named: "pluswhite.png"), for: UIControlState.normal)
            memory.setImage(UIImage(named: "mwhite.png"), for: UIControlState.normal)
            c.setImage(UIImage(named: "cwhite.png"), for: UIControlState.normal)
            ce.setImage(UIImage(named: "cewhite.png"), for: UIControlState.normal)
            Display.textColor = UIColor.white
            setColorScheme(color: UIColor.white)
            setColorSchemeForNumbers(color: UIColor(red: 0, green: 1, blue: 1, alpha: 1))
            c.setTitleColor(UIColor.white, for: UIControlState.normal)
            ce.setTitleColor(UIColor.white, for: UIControlState.normal)
            DegRadButton.setTitleColor(UIColor(red: 0, green: 1, blue: 1, alpha: 1), for: UIControlState.normal)
            
        }
    }
    
    
}


