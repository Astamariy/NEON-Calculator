//
//  Model.swift
//  Calculator PRO
//
//  Created by Александр Рузманов on 12.01.17.
//  Copyright © 2017 Александр Рузманов. All rights reserved.
//

import Foundation
import Darwin



private func calculatePower (x1: Double, x2: Double) -> Double
{
    if x1 < 0 && abs(x2) < 1 {
        let x = 1 / abs(x2)
        let a: Double = round(x.truncatingRemainder(dividingBy: 2) * 10000) / 10000
        let b: Double = 1
        
        if String(abs(a)) == String(b)
        {
        return -pow(-x1, x2)
        }}
    return pow(x1, x2)}
private func cosinus (x1: Double) -> Double {
    let a: Double = round(x1.truncatingRemainder(dividingBy: M_PI / 2) * 10000000) / 10000000
    if String(abs(a)) == String(0.0) {
        return round(abs(cos(x1)) * 10000000) / 10000000
    }
    return round(cos(x1) * 10000000) / 10000000
}
private func sinus (x1: Double) -> Double {
    let a: Double = round(x1.truncatingRemainder(dividingBy: M_PI) * 10000000) / 10000000
    if String(abs(a)) == String(0.0) {
        return round(abs(sin(x1)) * 10000000) / 10000000
    }
    return round(sin(x1) * 10000000) / 10000000
}


class Processor {

    private var accumulator: Double = 0
    var memory: Double?
   
    func saveData(value: Double)
    {
        memory = value
    }
    func resetData()
    {
    memory = nil
    }
    func setAccumulator(operand: Double)
    {
    accumulator = operand
    }
    
    private func logE(_val: Double) -> Double {
        return Double(log(_val) / log(M_E))
    }
    
    private var operationRecognizer = [
    "+": Operations.BinaryOperation({$0 + $1}),
    "-": Operations.BinaryOperation({$0 - $1}),
    "X": Operations.BinaryOperation({$0 * $1}),
    "/": Operations.BinaryOperation({$0 / $1}),
    "x^y": Operations.BinaryOperation({calculatePower(x1: $0, x2: $1)}), //doesn't work with minus
    "=": Operations.Equal,
    "1/x": Operations.UnaryOperation({1 / $0}),
    "+/-": Operations.UnaryOperation({-$0}),
    "√": Operations.UnaryOperation(sqrt),
    "∛": Operations.UnaryOperation({
        if $0 < 0
        {
            return -pow(-$0, 1 / 3)
        }
        else {
        return pow($0, 1 / 3)
        }
    }),
    "cos": Operations.UnaryOperation({
        cosinus(x1: $0)
        }),
    "sin": Operations.UnaryOperation({
        sinus(x1: $0)    }),
    "tg": Operations.UnaryOperation(
        {
            if abs(sinus(x1: $0) / cosinus(x1: $0)) == 0.0 {
                return abs(sinus(x1: $0) / cosinus(x1: $0))
            }
     return (sinus(x1: $0) / cosinus(x1: $0))
    }),
    "ln": Operations.UnaryOperation({log($0) / log(M_E)}),
    "lg": Operations.UnaryOperation({log($0) / log(10)}),
    "x!": Operations.UnaryOperation({
        var x = $0
        var fact = 1.0
        if x > 0 {
        while x > 1
        { fact = fact * x
            x -= 1
            }}
    return fact
        }),
    "e^x": Operations.UnaryOperation({pow(M_E, $0)}),
    "x^2": Operations.UnaryOperation({$0 * $0}),
    "e": Operations.Constant(M_E),
    "п": Operations.Constant(M_PI)
    ]
    
    private enum Operations {
        case Constant(Double)
        case UnaryOperation((Double) -> Double)
        case BinaryOperation((Double, Double) -> Double)
        case Equal
    }
    
    func returnAnswer(operationSymbol: String) -> String
    {
    if let dict = operationRecognizer[operationSymbol] {
        switch dict {
        case Operations.Constant(let constant): accumulator = constant
        case Operations.UnaryOperation(let function):

            
            if operationSymbol == "x!" && (accumulator < 0 || accumulator.truncatingRemainder(dividingBy: 1.0) != 0.0 || accumulator > 90) {
            return "ERROR"
            }
            
            accumulator = function(accumulator)

        case Operations.BinaryOperation(let function):
            if accumulator != pending?.point
            {
                BinaryOperation()
                pending = BinaryOperationInfo(point: accumulator, binaryFunction: function)
            }
            pending?.binaryFunction = function
            
        case Operations.Equal:
            BinaryOperation()
            pending = nil
        }
        
       
    }
        return String(accumulator)
    }
    
    private var pending: BinaryOperationInfo?
    
    func resetAll()
    {pending = nil
        accumulator = 0
    }
    
   private func BinaryOperation() {
        if pending != nil {
            accumulator = pending!.binaryFunction(pending!.point, accumulator)
            
        }
    }
    
    private struct BinaryOperationInfo {
        var point: Double
        var binaryFunction: (Double, Double) -> Double
        
        
    }
    
    
}
