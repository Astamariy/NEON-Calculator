//
//  InterfaceController.swift
//  NEONw calculator Extension
//
//  Created by Александр Рузманов on 25.01.17.
//  Copyright © 2017 Александр Рузманов. All rights reserved.
//

import WatchKit
import Foundation
import WatchConnectivity

class InterfaceController: WKInterfaceController {
    
    private var userIsTheMiddleOfTyping = false
    private var itIsFirstPushOnPointButton = true
    private var text: String = "0" {
        didSet {
            Display.setText(text)
        }
    }
    
    @IBOutlet private var Display: WKInterfaceLabel!
    
    
    
    // press numbers
    
    
    @IBAction private func pressOne() {
        if userIsTheMiddleOfTyping
        {
            if text != "0" {
                text = text + "1"
            }
            else {
                text = "1"
            }
            
        }
        else {
            text = "1"
            userIsTheMiddleOfTyping = true
        }
    }
    
    @IBAction private func pressTwo() {
        if userIsTheMiddleOfTyping
        {
            if text != "0" {
                text = text + "2"
            }
            else {
                text = "2"
            }
            
        }
        else {
            text = "2"
            userIsTheMiddleOfTyping = true
        }
    }
   
    @IBAction private func pressThree() {
        if userIsTheMiddleOfTyping
        {
            if text != "0" {
                text = text + "3"
            }
            else {
                text = "3"
            }
            
        }
        else {
            text = "3"
            userIsTheMiddleOfTyping = true
        }
    }
    
    @IBAction private func pressFour() {
        if userIsTheMiddleOfTyping
        {
            if text != "0" {
                text = text + "4"
            }
            else {
                text = "4"
            }
            
        }
        else {
            text = "4"
            userIsTheMiddleOfTyping = true
        }
    }
    
    @IBAction private func pressFive() {
        if userIsTheMiddleOfTyping
        {
            if text != "0" {
                text = text + "5"
            }
            else {
                text = "5"
            }
            
        }
        else {
            text = "5"
            userIsTheMiddleOfTyping = true
        }
    }
    
    @IBAction private func pressSix() {
        if userIsTheMiddleOfTyping
        {
            if text != "0" {
                text = text + "6"
            }
            else {
                text = "6"
            }
            
        }
        else {
            text = "6"
            userIsTheMiddleOfTyping = true
        }
    }
    
    @IBAction private func pressSeven() {
        if userIsTheMiddleOfTyping
        {
            if text != "0" {
                text = text + "7"
            }
            else {
                text = "7"
            }
            
        }
        else {
            text = "7"
            userIsTheMiddleOfTyping = true
        }
    }
    
    @IBAction private func pressEight() {
        if userIsTheMiddleOfTyping
        {
            if text != "0" {
                text = text + "8"
            }
            else {
                text = "8"
            }
            
        }
        else {
            text = "8"
            userIsTheMiddleOfTyping = true
        }
    }
    
    @IBAction private func pressNine() {
        if userIsTheMiddleOfTyping
        {
            if text != "0" {
                text = text + "9"
            }
            else {
                text = "9"
            }
            
        }
        else {
            text = "9"
            userIsTheMiddleOfTyping = true
        }
    }
    
    @IBAction private func pressZero() {
        if userIsTheMiddleOfTyping
        {
            if text != "0" {
                text = text + "0"
            }
            else {
                text = "0"
            }
            
        }
        else {
            text = "0"
            userIsTheMiddleOfTyping = true
        }
    }
    
    
    // functions
    
    
    @IBAction private func resetAll() {
        text = "0"
        userIsTheMiddleOfTyping = false
        itIsFirstPushOnPointButton = true
        pending = nil
    }
    
    @IBAction private func reset() {
        text = "0"
        userIsTheMiddleOfTyping = false
        itIsFirstPushOnPointButton = true
        
        }
    
    @IBAction private func oneDivideX() {
        if Double(text) != nil{
        setAccumulator(operand: Double(text)!)
        text = returnAnswer(operationSymbol: "1/x")
        } else {
            text = "ERROR"
        }
        userIsTheMiddleOfTyping = false
    }
    
    @IBAction private func changeSign() {
        if Double(text) != nil{
            setAccumulator(operand: Double(text)!)
            text = returnAnswer(operationSymbol: "+/-")
        } else {
            text = "ERROR"
        }
        userIsTheMiddleOfTyping = false
    }
    
    @IBAction private func pressPoint() {
        if itIsFirstPushOnPointButton {
            if userIsTheMiddleOfTyping {
                text = text + "."
                itIsFirstPushOnPointButton = false
                
            } else {
                if text == "0" {
                    text = text + "."
                    itIsFirstPushOnPointButton = false
                    userIsTheMiddleOfTyping = true
                    
                }
            }
        } else {
            
        }
        
    }
    
    @IBAction private func dividing() {
        if Double(text) != nil{
            setAccumulator(operand: Double(text)!)
            text = returnAnswer(operationSymbol: "/")
        } else {
            text = "ERROR"
        }

        userIsTheMiddleOfTyping = false
    }
    
    @IBAction private func multiply() {
        if Double(text) != nil{
            setAccumulator(operand: Double(text)!)
            text = returnAnswer(operationSymbol: "X")
        } else {
            text = "ERROR"
        }

        userIsTheMiddleOfTyping = false
    }
    
    @IBAction private func addition() {
        if Double(text) != nil{
            setAccumulator(operand: Double(text)!)
            text = returnAnswer(operationSymbol: "+")
        } else {
            text = "ERROR"
        }
        userIsTheMiddleOfTyping = false
        
    }
    
    @IBAction private func substraction() {
        if Double(text) != nil{
            setAccumulator(operand: Double(text)!)
            text = returnAnswer(operationSymbol: "-")
        } else {
            text = "ERROR"
        }

        userIsTheMiddleOfTyping = false
        
    }
    
    @IBAction private func equal() {
        if Double(text) != nil{
            setAccumulator(operand: Double(text)!)
            text = returnAnswer(operationSymbol: "=")
        } else {
            text = "ERROR"
        }

        userIsTheMiddleOfTyping = false
    }
    
    
    
    // brain, testing version
    
    
    private var accumulator: Double = 0
    private func setAccumulator(operand: Double)
    {
        accumulator = operand
    }
    
    private var operationRecognizer = [
        "+": Operations.BinaryOperation({$0 + $1}),
        "-": Operations.BinaryOperation({$0 - $1}),
        "X": Operations.BinaryOperation({$0 * $1}),
        "/": Operations.BinaryOperation({$0 / $1}),
        "=": Operations.Equal,
        "1/x": Operations.UnaryOperation({1 / $0}),
        "+/-": Operations.UnaryOperation({-$0})
    ]
    
    private enum Operations {
        case UnaryOperation((Double) -> Double)
        case BinaryOperation((Double, Double) -> Double)
        case Equal
    }
    
    private func returnAnswer(operationSymbol: String) -> String
    {
        if let dict = operationRecognizer[operationSymbol] {
            switch dict {
            case Operations.UnaryOperation(let function):
                accumulator = function(accumulator)
            case Operations.BinaryOperation(let function):
                if accumulator != pending?.point
                {
                    BinaryOperation()
                    pending = BinaryOperationInfo(point: accumulator, binaryFunction: function)
                }
                pending?.binaryFunction = function
            case Operations.Equal:
                BinaryOperation()
                pending = nil
            }
            
            
        }
        return String(accumulator)
    }
    
    private var pending: BinaryOperationInfo?
    
    
    private func BinaryOperation() {
        if pending != nil {
            accumulator = pending!.binaryFunction(pending!.point, accumulator)
            
        }
    }
    
    private struct BinaryOperationInfo {
        var point: Double
        var binaryFunction: (Double, Double) -> Double
    }

  
    
    
    override func awake(withContext context: Any?) {
        super.awake(withContext: context)
        
        // Configure interface objects here.
    }
    
    override func willActivate() {
        // This method is called when watch view controller is about to be visible to user
        super.willActivate()
        
    }
    
    override func didDeactivate() {
        // This method is called when watch view controller is no longer visible
        super.didDeactivate()
    }

}
