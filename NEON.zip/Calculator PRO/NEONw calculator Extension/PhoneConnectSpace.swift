//
//  PhoneConnectSpace.swift
//  NEON Calculator
//
//  Created by Александр Рузманов on 26.01.17.
//  Copyright © 2017 Александр Рузманов. All rights reserved.
//

import Foundation
import  WatchConnectivity

class PhoneConnectSpace: WCSession {
    
    private var session: WCSession? = nil
    
    func takeInfo() -> String {
        if WCSession.isSupported() {
            session = WCSession.default()
            session?.delegate = delegate.self
            session?.activate()
            return downloadInfo()
        } else {
            return "ERROR"
        }
    }
    
    private func downloadInfo() -> String {
        if let phoneDataBase = session?.receivedApplicationContext as? [String : String] {
            if phoneDataBase["Phone Display Walue"] != nil {
                return phoneDataBase["Phone Display Walue"]!
            } else {
                return "ERROR"
            }
        } else {
            return "ERROR"
        }
    }
    
    func shareInfo(displayValue: String) {
        if WCSession.isSupported() {
            session = WCSession.default()
            session?.delegate = delegate.self
            session?.activate()
            if let validSession = session {
                let watchDataBase = ["Watch Display Walue" : displayValue]
                do {
                    try validSession.updateApplicationContext(watchDataBase)
                } catch {
                    print("ERROR in share watch info process")
                }
            }
        } else {
            print("ERROR in session activate process (w)")
        }
        }
    
    init(displayValue: String) {
        
    }
        
    }
    
    
